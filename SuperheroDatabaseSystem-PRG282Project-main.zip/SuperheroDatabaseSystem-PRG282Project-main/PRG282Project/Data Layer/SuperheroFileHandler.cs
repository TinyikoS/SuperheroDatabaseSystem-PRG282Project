﻿using PRG282Project.Logic_Layer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO; //import to give access to file classes

namespace PRG282Project.Data_Layer
{
    internal class SuperheroFileHandler
    {
        private static string filePath = "superheroes.txt";

        public static void SaveHero(Superhero hero)
        {
            string filePath = "superhero.txt";
            string line = $"{hero.HeroID}, {hero.Name}, {hero.Age}, {hero.Superpower}, {hero.ExamScore},{hero.Rank}, {hero.ThreatLevel}";
            File.AppendAllText(filePath,line + Environment.NewLine);
        }

        public static List<Superhero> GetAllHeroes()
        {
            List<Superhero> heroes = new List<Superhero>();

            if (File.Exists(filePath)) 
            {
                string[] lines = File.ReadAllLines(filePath);

                foreach (var line in lines) 
                {
                    var parts = line.Split(',');
                    if(parts.Length ==7)
                    {
                        heroes.Add(new Superhero
                        {
                            HeroID = parts[0],
                            Name = parts[1],
                            Age = int.Parse(parts[2]),
                            Superpower = parts[3],
                            ExamScore = double.Parse(parts[4]),
                            Rank = parts[5],
                            ThreatLevel = parts[6]
                        });
                    }
                    
                }
            }

            return heroes;
        }

    }
}
