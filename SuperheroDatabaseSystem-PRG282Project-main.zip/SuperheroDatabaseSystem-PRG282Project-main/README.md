# SuperheroDatabaseSystem-PRG282Project
A C# Windows Forms application that manages superhero trainee records for One Kick Heroes Academy. The system tracks hero details, calculates ranks based on exam scores, and generates reports.
