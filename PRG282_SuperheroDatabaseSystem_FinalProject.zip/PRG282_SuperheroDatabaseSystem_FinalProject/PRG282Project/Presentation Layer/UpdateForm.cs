﻿using PRG282Project.Logic_Layer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRG282Project.Presentation_Layer
{
    public partial class UpdateForm : Form
    {
        public UpdateForm()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            //link to main form
            MainForm main = new MainForm();
            main.Show();
            this.Hide();
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            LoadSuperheroes();
        }

        private void LoadSuperheroes()
        {
            listView1.Items.Clear(); // clear any old records

            string filePath = Path.Combine(Application.StartupPath, "superheroes.txt");

            // check if the file exists
            if (!File.Exists(filePath))
            {
                MessageBox.Show("No superhero records found yet.");
                return;
            }

            // read each line in the file
            string[] lines = File.ReadAllLines(filePath);

            foreach (var line in lines)
            {
                if (string.IsNullOrWhiteSpace(line)) continue;

                string[] parts = line.Split(',');

                if (parts.Length >= 7)
                {
                    ListViewItem item = new ListViewItem(parts[0]); // Hero ID
                    item.SubItems.Add(parts[1]); // Name
                    item.SubItems.Add(parts[2]); // Age
                    item.SubItems.Add(parts[3]); // Superpower
                    item.SubItems.Add(parts[4]); // Exam Score
                    item.SubItems.Add(parts[5]); // Rank
                    item.SubItems.Add(parts[6]); // Threat Level

                    listView1.Items.Add(item);
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate inputs
                if (string.IsNullOrWhiteSpace(txtHeroID.Text))
                {
                    MessageBox.Show("Please enter a Hero ID.", "Validation Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtHeroID.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtFullName.Text))
                {
                    MessageBox.Show("Please enter a Full Name.", "Validation Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtFullName.Focus();
                    return;
                }

                if (cmbSuperpower.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select a Superpower.", "Validation Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cmbSuperpower.Focus();
                    return;
                }

                // Validate exam score range
                double examScore = (double)nupExamScore.Value;
                if (examScore < 0 || examScore > 100)
                {
                    MessageBox.Show("Exam Score must be between 0 and 100.", "Validation Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    nupExamScore.Focus();
                    return;
                }

                // Search for hero first
                Superhero existingHero = Superhero.SearchHeroByID(txtHeroID.Text.Trim());


                if (existingHero == null)
                {
                    MessageBox.Show("Hero ID not found. Please check the ID and try again.",
                        "Hero Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtHeroID.Focus();
                    return;
                }

                // Create updated hero object
                Superhero updatedHero = new Superhero
                {
                    HeroID = txtHeroID.Text.Trim(),
                    Name = txtFullName.Text.Trim(),
                    Age = (int)nupAge.Value,
                    Superpower = cmbSuperpower.SelectedItem.ToString(),
                    ExamScore = examScore
                };

                // Update hero (this will also recalculate rank and threat level)
                bool success = Superhero.UpdateHeroRecord(updatedHero);

                if (success)
                {
                    MessageBox.Show($"Hero '{updatedHero.Name}' updated successfully!\n\n" +
                        $"New Rank: {updatedHero.Rank}\n" +
                        $"Threat Level: {updatedHero.ThreatLevel}",
                        "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    ClearForm();
                }
                else
                {
                    MessageBox.Show("Failed to update hero. Please try again.",
                        "Update Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Invalid input format. Please check your entries.",
                    "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ClearForm()
        {
            txtHeroID.Clear();
            txtFullName.Clear();
            nupAge.Value = 16;
            cmbSuperpower.SelectedIndex = -1;
            nupExamScore.Value = 0;
            txtHeroID.Focus();
        }

        private void UpdateForm_Load(object sender, EventArgs e)
        {
            // Configure the ListView appearance
            listView1.View = View.Details;
            listView1.FullRowSelect = true;
            listView1.GridLines = true;

            // Define columns (only once)
            listView1.Columns.Add("Hero ID", 100);
            listView1.Columns.Add("Full Name", 150);
            listView1.Columns.Add("Age", 70);
            listView1.Columns.Add("Superpower", 130);
            listView1.Columns.Add("Exam Score", 100);
            listView1.Columns.Add("Rank", 100);
            listView1.Columns.Add("Threat Level", 120);

            // Load saved heroes automatically
            LoadSuperheroes();
        }
    }
    
}
