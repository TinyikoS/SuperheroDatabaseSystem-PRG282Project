﻿using PRG282Project.Data_Layer;
using PRG282Project.Logic_Layer;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace PRG282Project.Presentation_Layer
{
    public partial class DeleteForm : Form
    {
        public DeleteForm()
        {
            InitializeComponent();
        }

        // when the form opens, load all superheroes into the list view
        private void DeleteForm_Load(object sender, EventArgs e)
        {
            LoadSuperheroes();
        }

        // method to display all heroes from the file
        private void LoadSuperheroes()
        {
            listView1.Items.Clear(); // clear any old records

            string filePath = Path.Combine(Application.StartupPath, "superheroes.txt");

            // check if the file exists
            if (!File.Exists(filePath))
            {
                MessageBox.Show("No superhero records found yet.");
                return;
            }

            // read each line in the file
            string[] lines = File.ReadAllLines(filePath);

            foreach (var line in lines)
            {
                if (string.IsNullOrWhiteSpace(line)) continue;

                string[] parts = line.Split(',');

                if (parts.Length >= 7)
                {
                    ListViewItem item = new ListViewItem(parts[0]); // Hero ID
                    item.SubItems.Add(parts[1]); // Name
                    item.SubItems.Add(parts[2]); // Age
                    item.SubItems.Add(parts[3]); // Superpower
                    item.SubItems.Add(parts[4]); // Exam Score
                    item.SubItems.Add(parts[5]); // Rank
                    item.SubItems.Add(parts[6]); // Threat Level

                    listView1.Items.Add(item);
                }
            }
        }

        // when the View button is clicked
        private void btnView_Click(object sender, EventArgs e)
        {
            LoadSuperheroes();
        }

        // when the Delete button is clicked
        private void btnDelete_Click(object sender, EventArgs e)
        {
            string heroID = txtHeroID.Text.Trim(); // get text from textbox

            // if no ID entered, but a row is selected
            if (string.IsNullOrEmpty(heroID) && listView1.SelectedItems.Count > 0)
            {
                heroID = listView1.SelectedItems[0].Text; // use selected hero
            }

            // if still empty, ask the user to pick or type
            if (string.IsNullOrEmpty(heroID))
            {
                MessageBox.Show("Please type a Hero ID or select one from the list.");
                return;
            }

            // confirm deletion
            DialogResult result = MessageBox.Show(
                $"Are you sure you want to delete Hero ID: {heroID}?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                bool deleted = SuperheroFileHandler.DeleteHero(heroID);

                if (deleted)
                {
                    MessageBox.Show("Superhero deleted successfully!");
                    txtHeroID.Clear();
                    LoadSuperheroes(); // refresh list
                }
                else
                {
                    MessageBox.Show("No superhero found with that ID.");
                }
            }
            else
            {
                MessageBox.Show("Superhero deletion canceled.");
            }
        }

        // when the Back button is clicked
        private void btnBack_Click(object sender, EventArgs e)
        {
            MainForm main = new MainForm();
            main.Show();
            this.Hide();
        }

        // optional: runs when you select a row
        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // nothing needed here for now
        }

        private void txtHeroID_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
