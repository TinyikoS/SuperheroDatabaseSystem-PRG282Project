﻿using PRG282Project.Data_Layer;
using PRG282Project.Logic_Layer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO; //import for access to file classes
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRG282Project.Presentation_Layer
{
    public partial class InsertForm : Form
    {
        public InsertForm()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            //link to main form
            MainForm main = new MainForm();
            main.Show();
            this.Hide();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                //Validation
                if (string.IsNullOrWhiteSpace(txtHeroID.Text) ||
                   string.IsNullOrWhiteSpace(txtFullName.Text) ||
                   cmbSuperpower.SelectedItem == null)
                {
                    MessageBox.Show("Please fil in all required fields.");
                    return;
                }
                //Superhero Object using users input
                Superhero hero = new Superhero()
                {
                    HeroID = txtHeroID.Text,
                    Name = txtFullName.Text,
                    Age = (int)nupAge.Value,
                    Superpower = cmbSuperpower.SelectedItem.ToString(),
                    ExamScore = (double)nupExamScore.Value
                };

                //calculate rank and threat level
                hero.DetermineRankandThreat();

                //save to textfile
                SuperheroFileHandler.SaveHero(hero);

                MessageBox.Show("Superhero added successfully!");

                //clear fields
                txtHeroID.Clear();
                txtFullName.Clear();
                cmbSuperpower.SelectedIndex = -1;
                nupAge.Value = nupAge.Minimum;
                nupExamScore.Value = nupExamScore.Minimum;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving superher: " + ex.Message);
            }
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            LoadSuperheroes();
        }

        private void LoadSuperheroes()
        {
            lvSuperhero.Items.Clear(); // clear any old records

            string filePath = Path.Combine(Application.StartupPath, "superheroes.txt");

            // check if the file exists
            if (!File.Exists(filePath))
            {
                MessageBox.Show("No superhero records found yet.");
                return;
            }

            // read each line in the file
            string[] lines = File.ReadAllLines(filePath);

            foreach (var line in lines)
            {
                if (string.IsNullOrWhiteSpace(line)) continue;

                string[] parts = line.Split(',');

                if (parts.Length >= 7)
                {
                    ListViewItem item = new ListViewItem(parts[0]); // Hero ID
                    item.SubItems.Add(parts[1]); // Name
                    item.SubItems.Add(parts[2]); // Age
                    item.SubItems.Add(parts[3]); // Superpower
                    item.SubItems.Add(parts[4]); // Exam Score
                    item.SubItems.Add(parts[5]); // Rank
                    item.SubItems.Add(parts[6]); // Threat Level

                    lvSuperhero.Items.Add(item);
                }
            }
        }

        private void InsertForm_Load(object sender, EventArgs e)
        {
            // Configure the ListView appearance
            lvSuperhero.View = View.Details;
            lvSuperhero.FullRowSelect = true;
            lvSuperhero.GridLines = true;

            // Define columns (only once)
            lvSuperhero.Columns.Add("Hero ID", 100);
            lvSuperhero.Columns.Add("Full Name", 150);
            lvSuperhero.Columns.Add("Age", 70);
            lvSuperhero.Columns.Add("Superpower", 130);
            lvSuperhero.Columns.Add("Exam Score", 100);
            lvSuperhero.Columns.Add("Rank", 100);
            lvSuperhero.Columns.Add("Threat Level", 120);

            // Load saved heroes automatically
            LoadSuperheroes();
        }

        private void lvSuperhero_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }
    }
}
