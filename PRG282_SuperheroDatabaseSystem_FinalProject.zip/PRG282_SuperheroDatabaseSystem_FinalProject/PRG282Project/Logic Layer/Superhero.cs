﻿using PRG282Project.Data_Layer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRG282Project.Logic_Layer
{
    internal class Superhero
    {
        public string HeroID { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Superpower { get; set; }
        public double ExamScore { get; set; }
        public string Rank { get; set; }
        public string ThreatLevel { get; set; }

        public void DetermineRankandThreat()
        {
            if (ExamScore >= 81 && ExamScore<=100)
            {
                Rank = "S";
                ThreatLevel = "Finals Week (threat to the entire academy)";
            }
            else if (ExamScore >= 61 && ExamScore <= 80)
            {
                Rank = "A";
                ThreatLevel = "Midterm Madness (threat to a department)";
            }
            else if (ExamScore >= 41 && ExamScore <= 60)
            {
                Rank = "B";
                ThreatLevel = "Group Project Gone Wrong (threat to a study group)";
            }
            else if (ExamScore >=0 && ExamScore <= 40)
            {
                Rank = "C";
                ThreatLevel = "Pop Quiz (potential threat to an individual student)";
            }
            
        }

        public static Superhero SearchHeroByID(string heroID)
        {
            return SuperheroFileHandler.GetHeroByID(heroID);
        }

        public static bool UpdateHeroRecord(Superhero hero)
        {
            hero.DetermineRankandThreat();
            return SuperheroFileHandler.UpdateHero(hero);
        }

    }
}
