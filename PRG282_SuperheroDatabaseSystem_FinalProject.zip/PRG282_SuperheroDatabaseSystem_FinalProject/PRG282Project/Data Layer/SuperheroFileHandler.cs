﻿using PRG282Project.Logic_Layer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO; //import to give access to file classes
using System.Windows.Forms;

namespace PRG282Project.Data_Layer
{
    internal class SuperheroFileHandler
    {
        // file will be saved in the same folder where the app runs
        private static string filePath = Path.Combine(Application.StartupPath, "superheroes.txt");

        // save a new hero to the text file
        public static void SaveHero(Superhero hero)
        {
            using (StreamWriter sw = new StreamWriter(filePath, true))
            {
                sw.WriteLine($"{hero.HeroID},{hero.Name},{hero.Age},{hero.Superpower},{hero.ExamScore},{hero.Rank},{hero.ThreatLevel}");
            }
        }

        // read all heroes from the text file
        public static List<Superhero> GetAllHeroes()
        {
            List<Superhero> heroes = new List<Superhero>();

            if (File.Exists(filePath))
            {
                string[] lines = File.ReadAllLines(filePath);

                foreach (var line in lines)
                {
                    if (string.IsNullOrWhiteSpace(line)) continue;

                    var parts = line.Split(',');

                    if (parts.Length == 7)
                    {
                        heroes.Add(new Superhero
                        {
                            HeroID = parts[0],
                            Name = parts[1],
                            Age = int.Parse(parts[2]),
                            Superpower = parts[3],
                            ExamScore = double.Parse(parts[4]),
                            Rank = parts[5],
                            ThreatLevel = parts[6]
                        });
                    }
                }
            }

            return heroes;
        }

        // delete a hero by Hero ID
        public static bool DeleteHero(string heroID)
        {
            List<Superhero> heroes = GetAllHeroes();

            // find hero by ID
            var heroToDelete = heroes.FirstOrDefault(h => h.HeroID == heroID);

            if (heroToDelete != null)
            {
                heroes.Remove(heroToDelete);

                // rewrite the file without the deleted hero
                using (StreamWriter sw = new StreamWriter(filePath, false))
                {
                    foreach (var hero in heroes)
                    {
                        sw.WriteLine($"{hero.HeroID},{hero.Name},{hero.Age},{hero.Superpower},{hero.ExamScore},{hero.Rank},{hero.ThreatLevel}");
                    }
                }

                return true; 
            }

            return false;
        }

        public static bool UpdateHero(Superhero updatedHero)
        {
            if (!File.Exists(filePath))
            {
                return false;
            }

            List<Superhero> heroes = GetAllHeroes();
            bool heroFound = false;

            for (int i = 0; i < heroes.Count; i++)
            {
                if (heroes[i].HeroID == updatedHero.HeroID)
                {
                    heroes[i] = updatedHero;
                    heroFound = true;
                    break;
                }
            }

            if (heroFound)
            {
                // Rewrite the entire file with updated data
                File.WriteAllText(filePath, string.Empty);
                foreach (Superhero hero in heroes)
                {
                    string line = $"{hero.HeroID},{hero.Name},{hero.Age},{hero.Superpower},{hero.ExamScore},{hero.Rank},{hero.ThreatLevel}";
                    File.AppendAllText(filePath, line + Environment.NewLine);
                }
                return true;
            }

            return false;
        }

        public static Superhero GetHeroByID(string heroID)
        {
            List<Superhero> heroes = GetAllHeroes();
            foreach (Superhero hero in heroes)
            {
                if (hero.HeroID == heroID)
                {
                    return hero;
                }
            }
            return null;
        }
    }
}
